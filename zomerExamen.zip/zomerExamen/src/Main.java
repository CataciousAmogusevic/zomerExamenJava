import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args){
        int[][] inenuitMatrix ={
                {50,90,80,75,60},
                {-50,20,-90,-60,0},
                {-80,-75,45,70,0},
                {-20,-45,-70,85,95}
        };


        System.out.println(geefAantalPersonenPerRij(inenuitMatrix));
        System.out.println(geefGewichtenLijst(inenuitMatrix));
        System.out.println(geefVerdiepingBovenCapaciteit(inenuitMatrix, 600, 5));
        System.out.println(geefTeZwareVerdieping(inenuitMatrix, 400));
        System.out.println(geefVerdiepingMetTeVeelMensen(inenuitMatrix, 5));
    }


    public static List<Integer> geefAantalPersonenPerRij(int[][] inenuitMatrix){
        List<Integer> personenLijst = new ArrayList<>();
        int gewicht = 0;
        int personen = 0;
        for (int[] verdieping : inenuitMatrix) {
            gewicht += geefHoeveelheidVeranderdeGewicht(verdieping);
            personen += geefHoeveelheidVeranderdePersonen(verdieping);
            personenLijst.add(personen);
        }
        return personenLijst;
    }
    public static int geefHoeveelheidVeranderdePersonen(int[] verdieping) {
        int veranderdeMensenAantal = 0;
        for (int gewichtsTeller : verdieping) {
            if (gewichtsTeller > 0) {
                veranderdeMensenAantal++;
            } else if (gewichtsTeller < 0) {
                veranderdeMensenAantal--;
            }
        }
        return veranderdeMensenAantal;
    }
    public static int geefHoeveelheidVeranderdeGewicht(int[] verdieping) {
        int gewichtVerandering = 0;
        for (int gewicht : verdieping) {
            gewichtVerandering += gewicht;
        }
        return gewichtVerandering;
    }

    public static List<Integer> geefGewichtenLijst(int[][] inenuitMatrix) {
        List<Integer> gewichtenLijst = new ArrayList<>();
        int gewicht = 0;
        for (int[] verdieping : inenuitMatrix) {
            gewicht += geefHoeveelheidVeranderdeGewicht(verdieping);
            gewichtenLijst.add(gewicht);
        }
        return gewichtenLijst;
    }

    public static Integer geefVerdiepingBovenCapaciteit(int[][] inenuitMatrix, int maxGewicht, int maxMensen) {
        int gewicht = 0;
        int personen = 0;
        for (int teller = 0; teller < inenuitMatrix.length; teller++) {
            int[] verdieping = inenuitMatrix[teller];
            gewicht += geefHoeveelheidVeranderdeGewicht(verdieping);
            personen += geefHoeveelheidVeranderdePersonen(verdieping);
            if (personen > maxMensen) {
                System.out.println("te veel mensen");
                return teller;
            //geen else want het is een for loop en ik wil niet ten duizend "te veel mensen" of "ok gewicht" zien
            }
            if (gewicht > maxGewicht) {
                System.out.println("te zwaar");
                return teller;
            }

        }
        return null;
    }

    public static Integer geefTeZwareVerdieping(int[][] inenuitmatrix, int maxgewicht) {
        int gewicht = 0;
        for (int teller = 0; teller < inenuitmatrix.length; teller++){
            int[] verdieping = inenuitmatrix[teller];
            gewicht += geefHoeveelheidVeranderdeGewicht(verdieping);
            if (gewicht > maxgewicht) {
                return teller;
            }
        }
        return null;
    }

    public static Integer geefVerdiepingMetTeVeelMensen(int[][] inenuitmatrix, int maxMensen) {
        int personen = 0;
        for (int teller = 0; teller < inenuitmatrix.length; teller++) {
            int[] verdieping = inenuitmatrix[teller];
            personen += geefHoeveelheidVeranderdePersonen(verdieping);
            if (personen > maxMensen) {
                return teller;
            }
        }
        return null;
    }
   }